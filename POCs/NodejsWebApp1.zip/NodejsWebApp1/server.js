//"use strict";


var express = require("express");
var path = require("path");
var bodyParser = require("body-parser");
var mongodb = require('mongodb');
var request = require("request");
var app = express();
app.use(express.static(__dirname));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var server = app.listen(process.env.PORT || 8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
});

app.get("/", function (req, res) {
    res.end("success");
});
app.post("/getGAdata", function (req, res) {
    res.end(req.body.url);
    var MongoClient = mongodb.MongoClient;
    request(req.body.url, function (error, response, body) {
        var _index = 0;
        var url = 'mongodb://localhost:27017';
        MongoClient.connect(url, function (err, db) {
            console.log("DB is connect");
            
            if (err) {
                res.end('Unable to connect to the mongoDB server. Error:', err);
            } else {
                //HURRAY!! We are connected. :)
                JSON.parse(body).rows.forEach(function (item, index) {
                    db.collection(req.body.collection).insert({ productID: item[0], views: item[1] });
                    console.log("Row inserted: " + "productID: " + item[0] + ", views: " + item[1]);
                    _index = index;
                });
                console.log(_index + " rows inserted.");
                db.close();
            }
        });
        res.end(_index + " rows inserted.");
    });
});
// Create a database variable outside of the database connection callback to reuse the connection pool in your app.


// Connect to the database before starting the application server.


//var http = require('http');
//var port = process.env.port || 1337;
//var request = require("request");
//var mongodb = require('mongodb');
//http.createServer(function (req, res) {
//    res.writeHead(200, { 'Content-Type': 'text/plain' });


//    var MongoClient = mongodb.MongoClient;
//    request("https://www.googleapis.com/analytics/v3/data/ga?ids=ga%3A86837041&start-date=2016-08-08&end-date=yesterday&metrics=ga%3AproductDetailViews&dimensions=ga%3AproductSku&access_token=ya29.CjU6A8ZHx_4d3VHdfx85mmk1bof-kXCNwb8kruwEfr2x1gikstaWESqjPIVZb-LV8r-PKsGRkw", function (error, response, body) {

//        var url = 'mongodb://localhost:27017';
//        MongoClient.connect(url, function (err, db) {
//            //console.log(db);
//            if (err) {
//                res.end('Unable to connect to the mongoDB server. Error:', err);
//            } else {
//                //HURRAY!! We are connected. :)
//                JSON.parse(body).rows.forEach(function (item, index) {

//                   db.collection('products').insert({ productID: item[0], views: item[1] });
//                   // db.collection('testnalyticsdata', { strict: true }, function (err, collection) { });
//                    res.end('Connection established to', url);
//                    console.log(item[0]);
//                    console.log(item[1]);
//                });




//                // do some work here with the database.

//                //Close connection

//                db.close();
//            }
//        });
//      //  res.end(body);
//    });


//}).listen(port);
////# sourceMappingURL=server.js.map